
 Cmdow v1.4.3 for Windows NT4/2000/XP
 Copyright (C) 2001-2004 Ritchie Lawrence
 http://www.commandline.co.uk

 Terms of Use
 ------------

 This software is provided "as is", without any guarantee made as
 to its suitability or fitness for any particular use. It may
 contain bugs and use of this product is at your own risk. I take
 no responsibility for any damage that may be caused through its use. 

 This product is freeware. There is no fee for personal or
 corporate use. It may be freely distributed only in its original
 form and provided this text file is attached.


 Comments, Problems
 ------------------

 If you have any comments or problems regarding this software,
 please feel free to email me. The latest version of this product
 may be downloaded from my web site at http://www.commandline.co.uk.

 -- 
 Ritchie
